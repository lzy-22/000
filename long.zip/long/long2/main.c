
#include <stdio.h>
#include <stdbool.h>

#include "bsp.h"
#include "console.h"
#include "ls1c102.h"

#include "src/GPIO/user_gpio.h"
#include "src/WDG/ls1x_wdg.h"
#include "src/Step_Motor/step_motor.h"
#include "libc/stdio/printf.h"
#include "src/ADC/user_adc.h"

int y=1;
extern HW_PMU_t *g_pmu;
extern int printk(const char* format, ...);
extern int uart0_print(const char* format, ...);

int main(void)
{
    BYJ_gpio_init();
    shun90();
    
    adc_init();

    WdgInit();
   // printk("main() function\r\n");
    gpio_init(20, 1);// GPIO20 ʹ�����
   // gpio_init(13, 1);// �������� LED ��
   
    gpio_init(28, 1);
    
    gpio_write(28, 0);
    gpio_write(13, 1);
    delay_ms(100);
    gpio_write(13, 0);
    delay_ms(100);
    console0_init(9600);// ����0��ʼ����Ϊ����������
    int n=0;
  //  char string0[100] = "A";
   // char *string1 = "abc";
    unsigned int guang;
    for (;;)
    {
        //shun90();
        if(y==0)
        {
            y=1;
            gpio_write(28, 1);
            usart0_print("on\r\n");
            delay_ms(1000);
            gpio_write(28, 0);
            usart0_print("off\r\n");
        }
        int open=0;
        /*
        open=gpio_read(28);
        if(open==1&&n==0)
        {
            shun90();
            usart0_print("on");
            n++;
        }
        else if(open==0&&n==1)
        {
            ni90();
            usart0_print("off");
            n--;
        }
        */
        register unsigned int ticks;
        ticks = get_clock_ticks();
       // printk("tick count = %u\r\n", ticks);
        //printk("abcdefghijklmnopqrstuvwxyz\r\n");
        
        gpio_write(20, 1);// GPIO20 ����ߵ�ƽ
        delay_ms(100);
        gpio_write(20, 0);// GPIO20 ����͵�ƽ
        delay_ms(300);
       /*
        printk("ADC0 = %u\r\n", adc_read(0));
        guang=adc_read(0);
        if(guang<=190)
        {
            gpio_write(13, 1);
        }
        else if(guang>250)
        {
            gpio_write(13, 0);
        }
        */
      //  console_putstr(string0, 1);
       // printk("\r\n");
       // console_putstr(string1, 1);
       // printk("\r\n");
        
        //usart0_print("string1 = %s\r\n", string1);
    }

    /*
     * Never goto here!
     */
    return 0;
}

/*
 * @@ End
 */
