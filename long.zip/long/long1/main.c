#include <stdio.h>
#include <stdbool.h>

#include "bsp.h"
#include "console.h"
#include "ls1c102.h"

#include "src/GPIO/user_gpio.h"
#include "src/WDG/ls1x_wdg.h"
#include "src/Step_Motor/step_motor.h"
#include "libc/stdio/printf.h"
#include "src/ADC/user_adc.h"

int y=1;
extern HW_PMU_t *g_pmu;
extern int printk(const char* format, ...);
extern int uart0_print(const char* format, ...);

int main(void)
{
    BYJ_gpio_init();
    shun90();
    
    adc_init();

    WdgInit();
   // printk("main() function\r\n");
    gpio_init(20, 1);// GPIO20 ʹ�����
    gpio_init(13, 1);// �������� LED ��
   
    gpio_init(28, 0);
    gpio_init(27, 0);
    
    
 //   gpio_write(13, 1);
  //  delay_ms(100);
  //  gpio_write(13, 0);
  //  delay_ms(100);
    console0_init(9600);// ����0��ʼ����Ϊ����������
    int n=0,n1=0,n3=0;
  //  char string0[100] = "A";
   // char *string1 = "abc";
    unsigned int guang;
    for (;;)
    {
        //shun90();
        if(y==0)
        {
            y=1;
            gpio_write(13, 1);
            shun90();
            usart0_print("page on\xFF\xFF\xFF");
            delay_ms(1000);
            gpio_write(13, 0);
            ni90();
            usart0_print("page off\xFF\xFF\xFF");
        }
        int open=0,open1=0;
 
        open=gpio_read(28);
        open1=gpio_read(27);
        if(open==1&&n==0)
        {
            gpio_write(13, 1);
            shun90();
            usart0_print("page on\xFF\xFF\xFF");
            n++;
        }
        else if(open==0&&n==1)
        {
            gpio_write(13, 0);
            ni90();
            usart0_print("page off\xFF\xFF\xFF");
            n--;
        }
                open=gpio_read(28);
        if(open1==1&&n1==0)
        {
            gpio_write(13, 1);
            shun90();
            usart0_print("page on\xFF\xFF\xFF");
            n1++;
        }
        else if(open1==0&&n1==1)
        {
            gpio_write(13, 0);
            ni90();
            usart0_print("page off\xFF\xFF\xFF");
            n1--;
        }
        register unsigned int ticks;
        ticks = get_clock_ticks();
       // printk("tick count = %u\r\n", ticks);
        //printk("abcdefghijklmnopqrstuvwxyz\r\n");
        
        gpio_write(20, 1);// GPIO20 ����ߵ�ƽ
        delay_ms(100);
        gpio_write(20, 0);// GPIO20 ����͵�ƽ
        delay_ms(300);

       // printk("ADC0 = %u\r\n", adc_read(0));
        guang=adc_read(0);
        if(guang<=2000&&n3==0)
        {
            gpio_write(13, 1);
            shun90();
            usart0_print("page on\xFF\xFF\xFF");
            n3++;
        }
        else if(guang>2000&&n3==1)
        {
            gpio_write(13, 0);
            ni90();
            usart0_print("page on\xFF\xFF\xFF");
            n3--;
        }

      //  console_putstr(string0, 1);
       // printk("\r\n");
       // console_putstr(string1, 1);
       // printk("\r\n");
        
        //usart0_print("string1 = %s\r\n", string1);
    }

    /*
     * Never goto here!
     */
    return 0;
}

/*
 * @@ End
 */
