#include "step_motor.h"
#include "ls1c102.h"
#include "src/GPIO/user_gpio.h"

void BYJ_gpio_init()
{
    gpio_init(36, 1);                     //GPIO36 ʹ�����
    gpio_init(37, 1);                     //GPIO37 ʹ�����
    gpio_init(38, 1);                     //GPIO38 ʹ�����
    gpio_init(39, 1);                     //GPIO39 ʹ�����
}

void shun90(void)
{
    for(int i=0;i<126;i++)
    {
    gpio_write(36, (0xE&0x1));
    gpio_write(37, (0xE&0x2)>>1);
    gpio_write(38, (0xE&0x4)>>2);
    gpio_write(39, (0xE&0x8)>>3);
    
    gpio_write(36, (0x6&0x1));
    gpio_write(37, (0x6&0x2)>>1);
    gpio_write(38, (0x6&0x4)>>2);
    gpio_write(39, (0x6&0x8)>>3);
    
    gpio_write(36, (0x7&0x1));
    gpio_write(37, (0x7&0x2)>>1);
    gpio_write(38, (0x7&0x4)>>2);
    gpio_write(39, (0x7&0x8)>>3);
    
    gpio_write(36, (0x3&0x1));
    gpio_write(37, (0x3&0x2)>>1);
    gpio_write(38, (0x3&0x4)>>2);
    gpio_write(39, (0x3&0x8)>>3);
    
    gpio_write(36, (0xB&0x1));
    gpio_write(37, (0xB&0x2)>>1);
    gpio_write(38, (0xB&0x4)>>2);
    gpio_write(39, (0xB&0x8)>>3);
    
    gpio_write(36, (0x9&0x1));
    gpio_write(37, (0x9&0x2)>>1);
    gpio_write(38, (0x9&0x4)>>2);
    gpio_write(39, (0x9&0x8)>>3);
    
    gpio_write(36, (0xD&0x1));
    gpio_write(37, (0xD&0x2)>>1);
    gpio_write(38, (0xD&0x4)>>2);
    gpio_write(39, (0xD&0x8)>>3);
    
    gpio_write(36, (0xC&0x1));
    gpio_write(37, (0xC&0x2)>>1);
    gpio_write(38, (0xC&0x4)>>2);
    gpio_write(39, (0xC&0x8)>>3);
    }
    BYJ_gpio_stop();
}

void ni90(void)
{
    for(int i=0;i<126;i++)
    {
    gpio_write(36, (0xE&0x1));
    gpio_write(37, (0xE&0x2)>>1);
    gpio_write(38, (0xE&0x4)>>2);
    gpio_write(39, (0xE&0x8)>>3);

    gpio_write(36, (0xC&0x1));
    gpio_write(37, (0xC&0x2)>>1);
    gpio_write(38, (0xC&0x4)>>2);
    gpio_write(39, (0xC&0x8)>>3);

    gpio_write(36, (0xD&0x1));
    gpio_write(37, (0xD&0x2)>>1);
    gpio_write(38, (0xD&0x4)>>2);
    gpio_write(39, (0xD&0x8)>>3);

    gpio_write(36, (0x9&0x1));
    gpio_write(37, (0x9&0x2)>>1);
    gpio_write(38, (0x9&0x4)>>2);
    gpio_write(39, (0x9&0x8)>>3);

    gpio_write(36, (0xB&0x1));
    gpio_write(37, (0xB&0x2)>>1);
    gpio_write(38, (0xB&0x4)>>2);
    gpio_write(39, (0xB&0x8)>>3);

    gpio_write(36, (0x3&0x1));
    gpio_write(37, (0x3&0x2)>>1);
    gpio_write(38, (0x3&0x4)>>2);
    gpio_write(39, (0x3&0x8)>>3);

    gpio_write(36, (0x7&0x1));
    gpio_write(37, (0x7&0x2)>>1);
    gpio_write(38, (0x7&0x4)>>2);
    gpio_write(39, (0x7&0x8)>>3);

    gpio_write(36, (0x6&0x1));
    gpio_write(37, (0x6&0x2)>>1);
    gpio_write(38, (0x6&0x4)>>2);
    gpio_write(39, (0x6&0x8)>>3);
    }
    BYJ_gpio_stop();
}

void BYJ_gpio_stop(void)// �����������������ת��ΪGPIO���
{
    gpio_write(36, 0);
    gpio_write(37, 0);
    gpio_write(38, 0);
    gpio_write(39, 0);
}

